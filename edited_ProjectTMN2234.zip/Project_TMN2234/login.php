<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>FCSIT Meeting Room Booking and Management System</title>
  <link rel="stylesheet" href="projectstyle.css">

</head>
<body>
  <img src="images/focusIT.png" alt="FCSIT_LOGO"class="center" style="background-color:white;">
  <div class="textcenter">
  </br>
  <h1 style="color:red;">Meeting Room Booking and Management System</h1>
  </div>
  <div class="header">
  	<h2>Login</h2>
  </div>
	 
  <form method="post" action="login.php">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  		<label>Username</label>
  		<input type="text" name="username" >
  	</div>
  	<div class="input-group">
  		<label>Password</label>
  		<input type="password" name="password">
  	</div>
  	<div class="input-group">
  		<button type="submit" class="btn" name="login_user">Login</button>
  	</div>
  	<p>
  		Haven't register? <a href="register.php">Sign up</a>
  	</p>
	<p>
		Forgot your password? <a href="passwordreset.php">Reset password</a>
	</p>
  </form>
</body>
</html>