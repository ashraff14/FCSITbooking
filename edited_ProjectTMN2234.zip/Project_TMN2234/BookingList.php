
<!DOCTYPE html>


<html>

    <head>
        <title> FCSIT Meeting Room Booking and Management System</title>
        <link rel="stylesheet" href="projectstyle.css">
    </head>

    <body>
        <div class="topnav">
            <a href="index.php">Home</a>
            <a href="updateprofile.php">Update Profile</a>
            <a class="active" href="BookingList.php">User Dashboard</a>
            <a href="https://www.fcsit.unimas.my/contact">Contact</a>
            <a href="logout.php">Log Out</a>
          </div>

		  <form>
			<div class="Forheader">
			<h1>
			<b>Booking  List</b>
			</h1>
		</div>

 <?php
$mysqli = new mysqli('localhost','root','','project_tmn2234') or die(mysqli_error($mysqli));
 $result = $mysqli->query("SELECT * FROM booking ") or die ($mysqli->error);


?>
            <table class="table table-hover table-responsive-sm text-center">
                <thead>
                    <tr>
                        <th scope="col">Full Name</th>
                        <th scope="col">Guests</th>
                        <th scope="col">Reservation Date</th>
                        <th scope="col">Time Zone</th>
                        <th scope="col">Telephone</th>
                        <th class="table-danger" scope="col"></th>
                    </tr>
                </thead>
<?php
 while($row = $result->fetch_assoc()): ?>
                    <tr>
                     <td><?php echo $row['name']; ?></td>
                     <td><?php echo $row['num_guest']; ?></td>
                     <td><?php echo $row['date']; ?></td>
                     <td><?php echo $row['time']; ?></td>
                     <td><?php echo $row['phone']; ?></td>
                      <td></td>
					</tr>
					<?php endwhile; ?>


</form>
</html>