<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>New Password</title>
  <link rel="stylesheet" type="text/css" href="projectstyle.css">
</head>
<body>
  <div class="header">
  	<h2>New Password</h2>
  </div>
	
  <form method="post" action="newpassword.php">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  	  <label>New Password</label>
  	  <input type="password" name="newpassword" value="<?php echo $newpassword; ?>">
  	</div>
  	<div class="input-group">
  	  <label>Confirm Password</label>
  	  <input type="password" name="password" value="<?php echo $password; ?>">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="newpassword">Reset</button>
  	</div>
  </form>
</body>
</html>