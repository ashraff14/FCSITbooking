<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="projectstyle.css">
</head>
<body>

        <div class="topnav">
            <a class="active" href="index.php">Home</a>
            <a href="updateprofile.php">Update Profile</a>
            <a href="BookingList.php">User Dashboard</a>
            <a href="https://www.fcsit.unimas.my/contact">Contact</a>
            <a href="logout.php">Log Out</a>
          </div>

<div class="header">
	<h2>Welcome to FCSIT Meeting Room Booking and Management System</h2>
</div>

<div class="content">
  <h1>Meeting Rooms<h1>
  <br>Bilik Melati <img src="images/meeting.jpg" alt="bilik1"class="imagecenter"></br>
  <br>Bilik Mawar <img src="images/meeting2.jpg" alt="bilik2"class="imagecenter"></br>
  <br>Bilik Seroja <img src="images/meeting4.jpg" alt="bilik4"class="imagecenter"></br>
</div>
      <form>
      <div class="Forheader">
      <h1>
      <b>Booking  Form</b>
      </h1>
    </div>
    </div>
        <form action="server.php" method="POST">
            <div class="form-group">
      <label> Name</label>
                <input type="text" class="form-control" name="name" placeholder=" Name" required="required">
      <label><br>Room Name</br></label>
                <input type="text" class="form-control" name="room_name" placeholder=" Room Name" required="required">
        </div>

            <label>Enter Date</label>
          <input type="date" class="form-control" name="date" placeholder="Date" required="required">
            <div class="form-group">

    <label>Enter Time Zone</label>
    <select class="form-control" name="time">
    <option>08.00-12.00</option>
    <option>12.00-16.00</option>
    <option>16.00-20.00</option>
    <option>20.00-00.00</option>
    </select>
            </div>

           <div class="form-group">
            <label>Enter number of Capacity</label>
          <input type="number" class="form-control" min="1" name="num_guest" placeholder="Guests" required="required">
            </div>

            <div class="form-group">
            <label for="guests">Enter your Telephone Number</label>
                <input type="text" class="form-control" name="phone" placeholder="Phone" required="required">
            </div>

            <div class="form-group">
    <label class="checkbox-inline"><input type="checkbox" required="required"> I accept the <a href="#">Terms of Use</a> &amp; <a href="#">Privacy Policy</a></label>
            </div>

            <div class="form-group">
            <button type="submit" name="reserv-submit" class="btn btn-dark btn-lg btn-block">Submit Reservation</button>
            </div>

        </form>
        <br><br>
    </div>
     </form >
		
</body>
</html>