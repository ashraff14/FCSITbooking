<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Update Profile</title>
  <link rel="stylesheet" type="text/css" href="projectstyle.css">
</head>
<body>
		<div class="topnav">
            <a href="index.php">Home</a>
            <a class="active" href="updateprofile.php">Update Profile</a>
            <a href="BookingList.php">User Dashboard</a>
            <a href="https://www.fcsit.unimas.my/contact">Contact</a>
			<a href="logout.php">Log Out</a>
          </div>
  <div class="header">
  	<h2>Update Profile</h2>
  </div>
	
  <form method="post" action="register.php">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  	  <label>Contact Number</label>
  	  <input type="numeric" name="contactnum" value="<?php echo $contactnum; ?>">
  	</div>
  	<div class="input-group">
  	  <label>Email</label>
  	  <input type="email" name="email" value="<?php echo $email; ?>">
  	</div>
  	<div class="input-group">
  	  <label>New Password</label>
  	  <input type="password" name="password_1">
  	</div>
  	<div class="input-group">
  	  <label>Confirm password</label>
  	  <input type="password" name="password_2">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="reg_user">Update</button>
  	</div>
  
  </form>
</body>
</html>